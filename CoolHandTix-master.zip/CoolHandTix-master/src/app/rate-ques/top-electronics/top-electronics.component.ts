import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-electronics',
  templateUrl: './top-electronics.component.html',
  styleUrls: ['./top-electronics.component.css']
})
export class TopElectronicsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
