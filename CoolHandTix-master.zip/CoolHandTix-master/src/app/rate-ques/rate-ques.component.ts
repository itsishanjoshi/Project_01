import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rate-ques',
  templateUrl: './rate-ques.component.html',
  styleUrls: ['./rate-ques.component.css']
})
export class RateQuesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
