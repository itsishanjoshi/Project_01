import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loc-queries',
  templateUrl: './loc-queries.component.html',
  styleUrls: ['./loc-queries.component.css']
})
export class LocQueriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
