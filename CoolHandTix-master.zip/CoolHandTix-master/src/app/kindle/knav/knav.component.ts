import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-knav',
  templateUrl: './knav.component.html',
  styleUrls: ['./knav.component.css']
})
export class KnavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
