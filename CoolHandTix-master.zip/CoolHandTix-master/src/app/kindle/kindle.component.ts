import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kindle',
  templateUrl: './kindle.component.html',
  styleUrls: ['./kindle.component.css']
})
export class KindleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
